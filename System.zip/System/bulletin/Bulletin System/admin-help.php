<?php
session_start();
$bodyClass = 'admin-body';
if (isset($_SESSION['admin_theme'])) {
    if ($_SESSION['admin_theme'] === 'dark') {
        $bodyClass .= ' dark-theme';
    } elseif ($_SESSION['admin_theme'] === 'light') {
        $bodyClass .= ' light-theme';
    } elseif ($_SESSION['admin_theme'] === 'system') {
        $bodyClass .= ' system-theme';
    }
}
if (isset($_SESSION['admin_compactMode']) && $_SESSION['admin_compactMode']) {
    $bodyClass .= ' compact-mode';
}
if (isset($_SESSION['admin_highContrast']) && $_SESSION['admin_highContrast']) {
    $bodyClass .= ' high-contrast';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help Tickets - Admin Portal</title>
    <link rel="stylesheet" href="admin-styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="<?php echo $bodyClass; ?>">
    <div class="admin-container">
        <!-- Header -->
        <header class="admin-header">
            <div class="header-left">
                <img src="img/logo.png" alt="CVSU Logo" class="logo">
                <h1>Help Tickets</h1>
            </div>
        </header>

        <!-- Main Content -->
        <main class="admin-main">
            <div class="help-tickets-container" id="helpTicketsContainer">
                <!-- Help tickets will be populated here -->
            </div>

            <div class="back-button">
                <a href="admin-dashboard.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Back to admin page
                </a>
            </div>
        </main>
    </div>

    <!-- Ticket Response Modal -->
    <div class="modal" id="ticketResponseModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Respond to Ticket</h3>
                <span class="modal-close" id="ticketModalClose">&times;</span>
            </div>
            <div class="ticket-details">
                <div class="detail-group">
                    <label>Subject:</label>
                    <span id="ticketSubject"></span>
                </div>
                <div class="detail-group">
                    <label>Category:</label>
                    <span id="ticketCategory"></span>
                </div>
                <div class="detail-group">
                    <label>Priority:</label>
                    <span id="ticketPriority"></span>
                </div>
                <div class="detail-group">
                    <label>Description:</label>
                    <p id="ticketDescription"></p>
                </div>
                <div class="form-group">
                    <label for="ticketResponse">Admin Response</label>
                    <textarea id="ticketResponse" rows="4" placeholder="Enter your response..."></textarea>
                </div>
            </div>
            <div class="modal-actions">
                <button class="btn-secondary" onclick="closeTicketModal()">Cancel</button>
                <button class="btn-success" onclick="resolveTicket()">
                    <i class="fas fa-check"></i> Mark as Resolved
                </button>
            </div>
        </div>
    </div>

    <script src="admin-help.js"></script>
</body>
</html>