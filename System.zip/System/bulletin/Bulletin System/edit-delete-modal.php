<?php
// Modal logic for edit/delete modal
$show_edit_modal = isset($_POST['showEditModal']) || isset($_POST['edit_post_id']);
$show_delete_modal = isset($_POST['showDeleteModal']) || isset($_POST['delete_post_id']);
?>

<!-- Edit Post Modal -->
<div class="modal-overlay<?php echo $show_edit_modal ? ' active' : ''; ?>" id="editPostModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Edit Announcement</h2>
            <button class="modal-close" type="button" onclick="closeEditPostModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="modal-body">
            <form method="post" id="editPostForm">
                <input type="hidden" name="edit_post_id" id="edit_post_id">
                
                <div class="form-group">
                    <label for="edit_post_title">Title</label>
                    <input type="text" id="edit_post_title" name="edit_title" placeholder="What's happening?" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_post_content">Content</label>
                    <div style="margin-bottom: 8px; display: flex; gap: 8px;">
                        <button type="button" class="action-btn" id="edit-insert-image-btn" title="Insert Image"><i class="fas fa-image"></i> Insert Image</button>
                        <button type="button" class="action-btn" id="edit-insert-link-btn" title="Insert Link"><i class="fas fa-link"></i> Insert Link</button>
                        <input type="file" id="edit-image-upload-input" accept="image/*" style="display:none;" />
                    </div>
                    <textarea id="edit_post_content" name="edit_content" placeholder="Share your announcement..." rows="4"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="edit_post_department">Target Audience</label>
                    <div class="select-wrapper">
                        <select id="edit_post_department" name="edit_department" required>
                            <option value="all">All Departments</option>
                            <option value="1">DIT Only</option>
                            <option value="2">DOM Only</option>
                            <option value="3">DAS Only</option>
                            <option value="4">TED Only</option>
                        </select>
                        <i class="fas fa-chevron-down select-arrow"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="edit_publish_date">Publication Date</label>
                    <input type="date" id="edit_publish_date" name="edit_publish_date">
                </div>
                
                <div class="form-group">
                    <label for="edit_publish_time">Publication Time</label>
                    <input type="time" id="edit_publish_time" name="edit_publish_time">
                </div>
                
                <div class="form-actions">
                    <div class="action-buttons">
                        <button type="button" class="action-btn" onclick="closeEditPostModal()">
                            Cancel
                        </button>
                    </div>
                    
                    <div class="form-options">
                        <button type="submit" class="post-submit-btn">
                            Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Post Modal -->
<div class="modal-overlay<?php echo $show_delete_modal ? ' active' : ''; ?>" id="deletePostModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Delete Announcement</h2>
            <button class="modal-close" type="button" onclick="closeDeletePostModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="modal-body">
            <div class="delete-warning">
                <div class="warning-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <h3>Are you sure you want to delete this announcement?</h3>
                <p>This action cannot be undone. The announcement will be permanently removed from the system.</p>
            </div>
            
            <form method="post" id="deletePostForm">
                <input type="hidden" name="delete_post_id" id="delete_post_id">
                
                <div class="form-actions">
                    <div class="action-buttons">
                        <button type="button" class="action-btn" onclick="closeDeletePostModal()">
                            Cancel
                        </button>
                    </div>
                    
                    <div class="form-options">
                        <button type="submit" class="delete-submit-btn">
                            Delete Announcement
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
/* Edit/Delete Modal Specific Styles */
.delete-warning {
    text-align: center;
    padding: 20px 0;
    margin-bottom: 20px;
}

.warning-icon {
    font-size: 48px;
    color: #dc3545;
    margin-bottom: 16px;
}

.delete-warning h3 {
    color: #333;
    margin: 0 0 12px 0;
    font-size: 18px;
    font-weight: 600;
}

.delete-warning p {
    color: #6c757d;
    margin: 0;
    line-height: 1.5;
    font-size: 14px;
}

.delete-submit-btn {
    background: #dc3545;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.1s ease;
}

.delete-submit-btn:hover {
    background: #c82333;
    transform: translateY(-1px);
}

.delete-submit-btn:active {
    transform: translateY(0);
}

/* Enhanced form styling for edit modal */
#editPostModal .form-group input[type="date"],
#editPostModal .form-group input[type="time"] {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

#editPostModal .form-group input[type="date"]:focus,
#editPostModal .form-group input[type="time"]:focus {
    outline: none;
    border-color: #1b4332;
    box-shadow: 0 0 0 3px rgba(27, 67, 50, 0.1);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .delete-warning {
        padding: 16px 0;
    }
    
    .warning-icon {
        font-size: 36px;
    }
    
    .delete-warning h3 {
        font-size: 16px;
    }
    
    .delete-warning p {
        font-size: 13px;
    }
}

@media (max-width: 480px) {
    .delete-warning {
        padding: 12px 0;
    }
    
    .warning-icon {
        font-size: 32px;
    }
    
    .delete-submit-btn {
        padding: 10px 20px;
        font-size: 13px;
    }
}
</style>

<script>
// Edit/Delete Modal functionality
document.addEventListener('DOMContentLoaded', function() {
    // Only add event listeners if they haven't been added already
    if (window.editDeleteModalInitialized) {
        return;
    }
    window.editDeleteModalInitialized = true;
    
    // Close modals when clicking outside
    const modalOverlays = document.querySelectorAll('.modal-overlay');
    modalOverlays.forEach(overlay => {
        if (!overlay.hasAttribute('data-close-listener')) {
            overlay.setAttribute('data-close-listener', 'true');
            overlay.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                    this.style.display = 'none';
                }
            });
        }
    });

    const editInsertImageBtn = document.getElementById('edit-insert-image-btn');
    const editInsertLinkBtn = document.getElementById('edit-insert-link-btn');
    const editImageUploadInput = document.getElementById('edit-image-upload-input');
    const editContentTextarea = document.getElementById('edit_post_content');

    function insertAtCursor(textarea, text) {
        if (!textarea) return;
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const before = textarea.value.substring(0, start);
        const after = textarea.value.substring(end, textarea.value.length);
        textarea.value = before + text + after;
        textarea.selectionStart = textarea.selectionEnd = start + text.length;
        textarea.focus();
    }

    // Image upload functionality (like post modal)
    if (editInsertImageBtn && editImageUploadInput && editContentTextarea) {
        editInsertImageBtn.addEventListener('click', function(e) {
            e.preventDefault();
            editImageUploadInput.click();
        });

        editImageUploadInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                if (!file.type.startsWith('image/')) {
                    alert('Please select a valid image file');
                    return;
                }
                const formData = new FormData();
                formData.append('image', file);
                editInsertImageBtn.disabled = true;
                editContentTextarea.placeholder = 'Uploading image...';
                fetch('upload_image.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.imageUrl) {
                        insertAtCursor(editContentTextarea, `![Image](${data.imageUrl})`);
                    } else {
                        alert('Upload failed: ' + (data.message || 'Unknown error'));
                    }
                })
                .catch(error => {
                    alert('Upload failed: ' + error.message);
                })
                .finally(() => {
                    editInsertImageBtn.disabled = false;
                    editContentTextarea.placeholder = 'Share your announcement...';
                    editImageUploadInput.value = '';
                });
            }
        });
    }

    // Link insertion functionality (like post modal)
    if (editInsertLinkBtn && editContentTextarea) {
        editInsertLinkBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const url = prompt("Enter the URL:");
            if (url && url.trim()) {
                const title = prompt("Enter the link text:", "Link");
                const linkText = title && title.trim() ? title : "Link";
                insertAtCursor(editContentTextarea, `[${linkText}](${url.trim()})`);
            }
        });
    }
});

// Global functions for opening/closing modals
window.openEditPostModal = function(postId, title, content, department, imagePath, externalUrl, scheduledPublishAt) {
    // Fill the form fields
    document.getElementById('edit_post_id').value = postId;
    document.getElementById('edit_post_title').value = title;
    document.getElementById('edit_post_content').value = content;
    document.getElementById('edit_post_department').value = department;
    
    // Handle scheduled publish date/time
    if (scheduledPublishAt) {
        const dt = scheduledPublishAt.split(' ');
        document.getElementById('edit_publish_date').value = dt[0];
        document.getElementById('edit_publish_time').value = dt[1] ? dt[1].slice(0, 5) : '';
    } else {
        document.getElementById('edit_publish_date').value = '';
        document.getElementById('edit_publish_time').value = '';
    }
    
    // Show the modal
    const modal = document.getElementById('editPostModal');
    modal.classList.add('active');
    modal.style.display = 'flex';
};

window.closeEditPostModal = function() {
    const modal = document.getElementById('editPostModal');
    modal.classList.remove('active');
    modal.style.display = 'none';
    // Reset form
    document.getElementById('editPostForm').reset();
};

window.openDeletePostModal = function(postId) {
    document.getElementById('delete_post_id').value = postId;
    const modal = document.getElementById('deletePostModal');
    modal.classList.add('active');
    modal.style.display = 'flex';
};

window.closeDeletePostModal = function() {
    const modal = document.getElementById('deletePostModal');
    modal.classList.remove('active');
    modal.style.display = 'none';
    // Reset form
    document.getElementById('deletePostForm').reset();
};
</script> 