<?php
ob_start();
// Handle post submission (modal)
$post_success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submitPost'])) {
    global $con;

    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    
    // Initialize variables
    $image_path = null;
    $external_url = null;
    $clean_content = $content;
    
    // COMPLETELY NEW APPROACH: Use string functions instead of regex
    // Look for image pattern: ![Image](URL)
    $image_start = strpos($content, '![');
    if ($image_start !== false) {
        $image_end = strpos($content, ')', $image_start);
        if ($image_end !== false) {
            // Extract the full image markdown
            $image_markdown = substr($content, $image_start, $image_end - $image_start + 1);
            
            // Extract URL from within parentheses
            $url_start = strpos($image_markdown, '](') + 2;
            $url_end = strpos($image_markdown, ')', $url_start);
            if ($url_start > 1 && $url_end !== false) {
                $image_path = substr($image_markdown, $url_start, $url_end - $url_start);
                // Remove image markdown from content
                $clean_content = str_replace($image_markdown, '', $clean_content);
            }
        }
    }
    
    // Look for link pattern: [Text](URL) but not images
    $link_start = 0;
    while (($link_pos = strpos($clean_content, '[', $link_start)) !== false) {
        // Make sure it's not an image (doesn't have ! before it)
        if ($link_pos == 0 || $clean_content[$link_pos - 1] !== '!') {
            $link_end = strpos($clean_content, ')', $link_pos);
            if ($link_end !== false) {
                // Extract the full link markdown
                $link_markdown = substr($clean_content, $link_pos, $link_end - $link_pos + 1);
                
                // Extract URL from within parentheses
                $url_start = strpos($link_markdown, '](') + 2;
                $url_end = strpos($link_markdown, ')', $url_start);
                if ($url_start > 1 && $url_end !== false) {
                    $external_url = substr($link_markdown, $url_start, $url_end - $url_start);
                    // Remove link markdown from content
                    $clean_content = str_replace($link_markdown, '', $clean_content);
                    break; // Only get the first link
                }
            }
        }
        $link_start = $link_pos + 1;
    }
    
    // Clean up the content
    $clean_content = trim($clean_content);
    
    $department_raw = $_POST['department'] ?? '';
    $target_department_id = ($department_raw === 'all') ? null : intval($department_raw);
    $important = isset($_POST['important']) ? 1 : 0;
    $created_at = date('Y-m-d H:i:s');
    $user_id = $_SESSION['user_id'] ?? 1;

    // Get scheduled date/time
    $publish_date = $_POST['publish_date'] ?? '';
    $publish_time = $_POST['publish_time'] ?? '';
    if ($publish_date && $publish_time) {
        $scheduled_publish_at = $publish_date . ' ' . $publish_time . ':00';
        $is_scheduled = 1;
    } else {
        $scheduled_publish_at = null;
        $is_scheduled = 0;
    }

    // Debug logging
    error_log("=== STRING-BASED EXTRACTION DEBUG ===");
    error_log("Original content: " . $content);
    error_log("Extracted image_path: " . ($image_path ?? 'NULL'));
    error_log("Extracted external_url: " . ($external_url ?? 'NULL'));
    error_log("Clean content: " . $clean_content);

    // Check if user exists and insert post
    if (isset($con) && $con) {
        $user_check = $con->prepare("SELECT user_id FROM signuptbl WHERE user_id = ?");
        if ($user_check) {
            $user_check->bind_param("i", $user_id);
            $user_check->execute();
            $user_check->store_result();
            if ($user_check->num_rows > 0) {
                $user_check->close();

                if ($title && isset($_POST['department'])) {
                    $post_type = 'Department';
                    $status = $is_scheduled ? 'Scheduled' : 'Published';
                    $view_count = 0;
                    $published_at = $created_at;
                    $updated_at = $created_at;
                    $last_edited_at = $created_at;
                    $last_edited_by_user_id = $user_id;

                    // Insert post with extracted values
                    $stmt = $con->prepare(
                        "INSERT INTO posts (user_id, title, content, post_type, target_department_id, is_super_important, is_scheduled, scheduled_publish_at, status, view_count, created_at, published_at, updated_at, last_edited_at, last_edited_by_user_id, image_path, external_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                    );

                    if ($stmt) {
                        $stmt->bind_param(
                            "isssiiississsisss",
                            $user_id,
                            $title,
                            $clean_content,        // Clean content without markdown
                            $post_type,
                            $target_department_id,
                            $important,
                            $is_scheduled,
                            $scheduled_publish_at,
                            $status,
                            $view_count,
                            $created_at,
                            $published_at,
                            $updated_at,
                            $last_edited_at,
                            $last_edited_by_user_id,
                            $image_path,           // Extracted image URL
                            $external_url          // Extracted link URL
                        );
                        
                        if ($stmt->execute()) {
                            $new_post_id = $con->insert_id;
                            $post_success = "Announcement posted successfully!";
                            
                            // Debug: Verify what was inserted
                            $verify_stmt = $con->prepare("SELECT content, image_path, external_url FROM posts WHERE post_id = ?");
                            $verify_stmt->bind_param("i", $new_post_id);
                            $verify_stmt->execute();
                            $verify_result = $verify_stmt->get_result();
                            $verify_row = $verify_result->fetch_assoc();
                            error_log("=== DATABASE VERIFICATION ===");
                            error_log("Stored content: " . ($verify_row['content'] ?? 'NULL'));
                            error_log("Stored image_path: " . ($verify_row['image_path'] ?? 'NULL'));
                            error_log("Stored external_url: " . ($verify_row['external_url'] ?? 'NULL'));
                            $verify_stmt->close();
                            
                            // Notification logic (keeping your existing code)
                            $poster_id = $user_id;
                            $post_department_id = $target_department_id;
                            $notify_users = [];
                            
                            if ($post_department_id === null) {
                                $user_q = $con->query("SELECT user_id FROM signuptbl WHERE user_id != $poster_id");
                                if ($user_q) {
                                    while ($row = $user_q->fetch_assoc()) {
                                        $notify_users[] = $row['user_id'];
                                    }
                                    $user_q->close();
                                }
                            } else {
                                $user_q = $con->prepare("SELECT user_id FROM signuptbl WHERE department_id = ? AND user_id != ?");
                                if ($user_q) {
                                    $user_q->bind_param("ii", $post_department_id, $poster_id);
                                    $user_q->execute();
                                    $user_q->bind_result($notify_user_id);
                                    while ($user_q->fetch()) {
                                        $notify_users[] = $notify_user_id;
                                    }
                                    $user_q->close();
                                }
                            }
                            
                            if (!$is_scheduled) {
                                foreach ($notify_users as $notify_user_id) {
                                    $msg = "A new announcement has been posted!";
                                    $type = "new_post";
                                    $stmt_n = $con->prepare("INSERT INTO notifications (user_id, notification_type, message, related_post_id, is_read) VALUES (?, ?, ?, ?, 0)");
                                    if ($stmt_n) {
                                        $stmt_n->bind_param("issi", $notify_user_id, $type, $msg, $new_post_id);
                                        $stmt_n->execute();
                                        $stmt_n->close();
                                    }
                                }
                            }

                            header("Location: dashboard.php");
                            exit();
                        } else {
                            $post_success = "Failed to post: " . $stmt->error;
                            error_log("Insert failed: " . $stmt->error);
                        }
                        $stmt->close();
                    } else {
                        $post_success = "Failed to prepare statement: " . $con->error;
                    }
                } else {
                    $post_success = "Title and department are required.";
                }
            } else {
                $post_success = "User not found.";
                $user_check->close();
            }
        } else {
            $post_success = "Database error: " . $con->error;
        }
    } else {
        $post_success = "Database connection not available.";
    }
}

// Modal logic
$show_post_modal = isset($_POST['showPostModal']) || isset($_POST['submitPost']);
?>

<!-- Your existing modal HTML stays the same -->
<div class="modal-overlay<?php echo $show_post_modal ? ' active' : ''; ?>" id="postModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>New Announcement</h2>
            <form method="post" style="display:inline; float:right;">
                <button class="modal-close" name="closePostModal" type="submit" style="background:none;border:none;">
                    <i class="fas fa-times"></i>
                </button>
            </form>
        </div>
        
        <div class="modal-body">
            <?php if (!empty($post_success)): ?>
                <div class="notification" style="margin-bottom: 15px; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; color: #155724;">
                    <?php echo htmlspecialchars($post_success); ?>
                </div>
            <?php endif; ?>
            
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="postTitle">Title</label>
                    <input type="text" id="postTitle" name="title" placeholder="What's happening?" required>
                </div>
                
                <div class="form-group">
                    <label for="postContent">Content</label>
                    <textarea id="postContent" name="content" placeholder="Share your announcement..." rows="4"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="postDepartment">Target Audience</label>
                    <div class="select-wrapper">
                        <select id="postDepartment" name="department" required>
                            <option value="" disabled selected>Select Target Audience</option>
                            <option value="all">All Departments</option>
                            <option value="1">DIT Only</option>
                            <option value="2">DOM Only</option>
                            <option value="3">DAS Only</option>
                            <option value="4">TED Only</option>
                        </select>
                        <i class="fas fa-chevron-down select-arrow"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="publish_date">Publication Date</label>
                    <input type="date" id="publish_date" name="publish_date">
                </div>
                <div class="form-group">
                    <label for="publish_time">Publication Time</label>
                    <input type="time" id="publish_time" name="publish_time">
                </div>
                
                <div class="form-actions">
                    <div class="action-buttons">
                        <button type="button" class="action-btn" id="insertImageBtn" title="Add Image">
                            <i class="fas fa-image"></i>
                        </button>
                        <button type="button" class="action-btn" id="insertLinkBtn" title="Add Link">
                            <i class="fas fa-link"></i>
                        </button>
                        <input type="file" id="imageUploadInput" accept="image/*" style="display:none;" />
                    </div>
                    
                    <div class="form-options">
                        <label class="checkbox-container">
                            <input type="checkbox" id="markImportant" name="important">
                            <span class="checkmark"></span>
                            Mark as important
                        </label>
                        
                        <button type="submit" class="post-submit-btn" name="submitPost">
                            Post
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const insertImageBtn = document.getElementById('insertImageBtn');
    const insertLinkBtn = document.getElementById('insertLinkBtn');
    const imageUploadInput = document.getElementById('imageUploadInput');
    const postContent = document.getElementById('postContent');

    function insertAtCursor(textarea, text) {
        if (!textarea) return;
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const before = textarea.value.substring(0, start);
        const after = textarea.value.substring(end, textarea.value.length);
        textarea.value = before + text + after;
        textarea.selectionStart = textarea.selectionEnd = start + text.length;
        textarea.focus();
    }

    // Image upload functionality
    if (insertImageBtn && imageUploadInput && postContent) {
        insertImageBtn.addEventListener('click', function(e) {
            e.preventDefault();
            imageUploadInput.click();
        });

        imageUploadInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            
            if (file) {
                if (!file.type.startsWith('image/')) {
                    alert('Please select a valid image file');
                    return;
                }
                
                const formData = new FormData();
                formData.append('image', file);

                insertImageBtn.disabled = true;
                postContent.placeholder = 'Uploading image...';

                fetch('upload_image.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.imageUrl) {
                        insertAtCursor(postContent, `![Image](${data.imageUrl})`);
                    } else {
                        alert('Upload failed: ' + (data.message || 'Unknown error'));
                    }
                })
                .catch(error => {
                    alert('Upload failed: ' + error.message);
                })
                .finally(() => {
                    insertImageBtn.disabled = false;
                    postContent.placeholder = 'Share your announcement...';
                    imageUploadInput.value = '';
                });
            }
        });
    }

    // Link insertion functionality
    if (insertLinkBtn && postContent) {
        insertLinkBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const url = prompt("Enter the URL:");
            if (url && url.trim()) {
                const title = prompt("Enter the link text:", "Link");
                const linkText = title && title.trim() ? title : "Link";
                insertAtCursor(postContent, `[${linkText}](${url.trim()})`);
            }
        });
    }
});
</script>

<?php ob_end_flush(); ?>